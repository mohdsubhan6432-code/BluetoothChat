package com.example.bluetoothchat

import android.Manifest
import android.app.Activity
import android.bluetooth.*
import android.content.*
import android.content.pm.PackageManager
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.View
import android.widget.*
import java.io.IOException
import java.io.InputStream
import java.io.OutputStream
import java.util.UUID

class MainActivity : Activity() {
    private lateinit var adapter: BluetoothAdapter
    private lateinit var status: TextView
    private lateinit var list: ListView
    private lateinit var message: EditText
    private val devices = mutableListOf<BluetoothDevice>()
    private val names = mutableListOf<String>()
    private val handler = Handler(Looper.getMainLooper())
    private var socket: BluetoothSocket? = null
    private var writer: OutputStream? = null
    private val uuid: UUID = UUID.fromString("8ce255c0-200a-11e0-ac64-0800200c9a66")

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        status = findViewById(R.id.status); list = findViewById(R.id.devices)
        message = findViewById(R.id.message)
        adapter = (getSystemService(BLUETOOTH_SERVICE) as BluetoothManager).adapter
        requestBtPermissions()

        findViewById<Button>(R.id.enableBtn).setOnClickListener { enableBluetooth() }
        findViewById<Button>(R.id.discoverBtn).setOnClickListener { makeDiscoverableAndDiscover() }
        findViewById<Button>(R.id.sendBtn).setOnClickListener { sendMessage() }
        list.setOnItemClickListener { _, _, pos, _ -> connect(devices[pos]) }
        startServer()
    }

    private fun requestBtPermissions() {
        if (android.os.Build.VERSION.SDK_INT >= 31) requestPermissions(
            arrayOf(Manifest.permission.BLUETOOTH_SCAN, Manifest.permission.BLUETOOTH_CONNECT), 10)
    }

    private fun hasConnect() = android.os.Build.VERSION.SDK_INT < 31 ||
        checkSelfPermission(Manifest.permission.BLUETOOTH_CONNECT) == PackageManager.PERMISSION_GRANTED
    private fun hasScan() = android.os.Build.VERSION.SDK_INT < 31 ||
        checkSelfPermission(Manifest.permission.BLUETOOTH_SCAN) == PackageManager.PERMISSION_GRANTED

    private fun enableBluetooth() {
        if (!hasConnect()) { requestBtPermissions(); return }
        if (!adapter.isEnabled) startActivityForResult(Intent(BluetoothAdapter.ACTION_REQUEST_ENABLE), 1)
        else status.text = "Bluetooth is ON"
    }

    private fun makeDiscoverableAndDiscover() {
        if (!hasConnect() || !hasScan()) { requestBtPermissions(); return }
        if (!adapter.isEnabled) { enableBluetooth(); return }
        startActivity(Intent(BluetoothAdapter.ACTION_REQUEST_DISCOVERABLE).apply {
            putExtra(BluetoothAdapter.EXTRA_DISCOVERABLE_DURATION, 300)
        })
        devices.clear(); names.clear()
        adapter.bondedDevices.forEach { d -> devices.add(d); names.add("${d.name ?: "Unknown"}\n${d.address}") }
        list.adapter = ArrayAdapter(this, android.R.layout.simple_list_item_1, names)
        adapter.startDiscovery()
        status.text = "Choose a paired device. For new devices, pair them in Bluetooth settings first."
    }

    private fun startServer() {
        Thread {
            try {
                val server = adapter.listenUsingRfcommWithServiceRecord("BluetoothChat", uuid)
                val s = server.accept()
                socket = s; writer = s.outputStream
                listen(s.inputStream)
                server.close()
            } catch (e: Exception) { }
        }.start()
    }

    private fun connect(device: BluetoothDevice) {
        Thread {
            try {
                if (!hasConnect()) return@Thread
                adapter.cancelDiscovery()
                val s = device.createRfcommSocketToServiceRecord(uuid)
                s.connect(); socket = s; writer = s.outputStream
                handler.post { status.text = "Connected to ${device.name ?: device.address}" }
                listen(s.inputStream)
            } catch (e: Exception) {
                handler.post { Toast.makeText(this, "Connection failed: ${e.message}", Toast.LENGTH_LONG).show() }
            }
        }.start()
    }

    private fun listen(input: InputStream) {
        val buffer = ByteArray(1024)
        while (true) {
            try {
                val n = input.read(buffer)
                if (n <= 0) break
                val text = String(buffer, 0, n, Charsets.UTF_8)
                handler.post { Toast.makeText(this, "Received: $text", Toast.LENGTH_LONG).show() }
            } catch (_: IOException) { break }
        }
    }

    private fun sendMessage() {
        val text = message.text.toString().trim()
        if (text.isEmpty()) return
        Thread {
            try {
                writer?.write(text.toByteArray(Charsets.UTF_8))
                handler.post { message.text.clear() }
            } catch (_: Exception) {
                handler.post { Toast.makeText(this, "Not connected", Toast.LENGTH_SHORT).show() }
            }
        }.start()
    }
}
